package com.example.employee_management_system.projection;

public interface EmployeeBasicInfo {
    Long getId();
    String getName();
    String getEmail();  
}
