package com.example.employee_management_system.projection;

public interface DepartmentBasicInfo {
    Long getId();
    String getName();
}
